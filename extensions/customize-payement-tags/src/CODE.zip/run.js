// @ts-check



/**
 * @typedef {import("../generated/api").RunInput} RunInput
 * @typedef {import("../generated/api").FunctionRunResult} FunctionRunResult
 */

/**
 * @type {FunctionRunResult}
 */
const NO_CHANGES = {
  operations: [],
};

/**
 * @param {RunInput} input
 * @returns {FunctionRunResult}
 */
export function run(input) {
  // Define the payment method name to hide
  
  // Extract payment methods and customer tags from input
  // const paymentMethods = input?.paymentMethods || [];
  const customerTags = input?.cart?.buyerIdentity?.customer?.hasTags || [];

  // Find the ID of the payment method to hide
  const hidePaymentMethodID = "gid://shopify/PaymentCustomizationPaymentMethod/3";
  
  
  // Check if any customer tag is in the restricted tags
  const hasRestrictedTag = customerTags.some(tagInfo => tagInfo.hasTag);
  //If Restricted tags exist and hide payment method
  //id exists, then disable the paymentid
  if (hasRestrictedTag && hidePaymentMethodID) {
    return NO_CHANGES;  
  }

  // Return no changes if no restricted tags are found or if the payment method is not found
  
  
  return {
    operations: [{
      hide: {
        paymentMethodId: hidePaymentMethodID
      }
    }]
  };
};